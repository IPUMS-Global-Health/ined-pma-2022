
Fixes latest warnings for M1mac in addition to minor updates
to reflect new warnings from depedency packages.

## Test environments

* local R installation, R 4.0.3
* MacOS (on Github Actions), R-release
* win-builder (devel)
* `rhub::check_for_cran()`

## R CMD check results

0 errors | 0 warnings | 0 notes
